using UnityEngine;

/// <summary>
/// Plays one of several clips with a little random pitch/volume so repeated sounds
/// (footsteps, landings, coins) never feel robotic.
/// Drop it on any GameObject, assign clips, then call Play() from your own code or an animation event.
/// </summary>
[RequireComponent(typeof(AudioSource))]
public class SfxPlayer : MonoBehaviour
{
    [SerializeField] private AudioClip[] variants;
    [Range(0f, 0.3f)] [SerializeField] private float pitchJitter = 0.08f;
    [Range(0f, 0.5f)] [SerializeField] private float volumeJitter = 0.1f;

    private AudioSource source;

    private void Awake()
    {
        source = GetComponent<AudioSource>();
        source.playOnAwake = false;
        source.loop = false;
    }

    public void Play()
    {
        if (variants == null || variants.Length == 0) return;
        source.pitch = 1f + Random.Range(-pitchJitter, pitchJitter);
        source.PlayOneShot(variants[Random.Range(0, variants.Length)], 1f - Random.Range(0f, volumeJitter));
    }
}
