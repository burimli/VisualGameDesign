"""Minimal DSP toolkit (numpy only) for the dark-retro dungeon sound pack."""
import wave
import numpy as np

SR = 44100
rng = np.random.default_rng(1337)


# ---------------------------------------------------------------- basics
def n_(d):
    return int(round(d * SR))


def tt(d):
    return np.arange(n_(d)) / SR


def nrm(x):
    m = np.max(np.abs(x))
    return x / m if m > 1e-9 else x


def norm(x, peak=0.9):
    m = np.max(np.abs(x))
    return x * (peak / m) if m > 1e-9 else x


def delay(x, s):
    return np.concatenate([np.zeros(n_(s)), x])


def mix(*arrs):
    L = max(len(a) for a in arrs)
    out = np.zeros(L)
    for a in arrs:
        out[:len(a)] += a
    return out


def place(buf, snd, pos_s, gain=1.0, wrap=False):
    """Add snd into buf at pos_s seconds. wrap=True lets the tail wrap round (for loops)."""
    i = int(round(pos_s * SR))
    L = len(buf)
    if wrap:
        np.add.at(buf, (np.arange(len(snd)) + i) % L, snd * gain)
    elif i < L:
        seg = snd[:L - i]
        buf[i:i + len(seg)] += seg * gain
    return buf


def wrap_tail(y, L):
    out = np.zeros(L)
    for i in range(0, len(y), L):
        seg = y[i:i + L]
        out[:len(seg)] += seg
    return out


# ---------------------------------------------------------------- oscillators / envelopes
def osc(kind, f, duty=0.5):
    f = np.asarray(f, dtype=float)
    ph = (np.cumsum(f) / SR) % 1.0
    if kind == 'sq':
        return np.where(ph < duty, 1.0, -1.0)
    if kind == 'saw':
        return 2 * ph - 1
    if kind == 'tri':
        return 4 * np.abs(ph - 0.5) - 1
    if kind == 'sin':
        return np.sin(2 * np.pi * ph)
    if kind == 'nz':  # sample-and-hold noise at rate f (Hz)
        idx = np.floor(np.cumsum(f) / SR).astype(int)
        vals = rng.uniform(-1, 1, idx[-1] + 2)
        return vals[idx]
    raise ValueError(kind)


def fcurve(f0, f1, d, mode='exp'):
    u = np.linspace(0, 1, n_(d), endpoint=False)
    if mode == 'exp':
        return f0 * (f1 / f0) ** u
    return f0 + (f1 - f0) * u


def env(d, a=0.002, decay=None, r=0.01, flat=False):
    n = n_(d)
    t = np.arange(n) / SR
    e = np.minimum(1.0, t / max(a, 1e-5))
    if not flat:
        e = e * (np.exp(-t / decay) if decay else (1 - t / d))
    return e * np.clip((d - t) / max(r, 1e-5), 0, 1)


def tone(kind, f0, f1=None, d=0.2, vol=1.0, decay=None, duty=0.5, mode='exp',
         vib=0, vibdepth=0.015, a=0.002, r=0.01, flat=False):
    if f1 is None:
        f1 = f0
    f = fcurve(f0, f1, d, mode)
    if vib:
        f = f * (1 + vibdepth * np.sin(2 * np.pi * vib * tt(d)))
    return osc(kind, f, duty) * env(d, a, decay, r, flat) * vol


def nt(kind, f, start, dur, vol=0.4, **kw):
    """A single delayed note."""
    return delay(tone(kind, f, f, dur, vol=vol, **kw), start)


def noise(d, vol=1.0, decay=None, lp=None, hp=None, a=0.001, r=0.01, flat=False, order=2):
    x = rng.uniform(-1, 1, n_(d))
    if hp:
        x = hpf(x, hp, order)
    if lp:
        x = lpf(x, lp, order)
    if hp or lp:
        x = nrm(x)
    return x * env(d, a, decay, r, flat) * vol


def bell(f, d=0.6, vol=1.0, decay=0.25):
    out = np.zeros(n_(d))
    for ratio, g in ((1, 1.0), (2.76, 0.5), (5.4, 0.25), (8.93, 0.12)):
        if f * ratio < 18000:
            out += tone('sin', f * ratio, f * ratio, d, decay=decay / (1 + 0.6 * (ratio - 1)), vol=g)
    return out * vol


# ---------------------------------------------------------------- filters
def _filt(x, hfn, circular):
    n = len(x)
    N = n if circular else 2 * n
    X = np.fft.rfft(x, N)
    f = np.fft.rfftfreq(N, 1 / SR)
    return np.fft.irfft(X * hfn(f), N)[:n]


def lpf(x, fc, order=2, circular=False):
    return _filt(x, lambda f: 1 / np.sqrt(1 + (f / fc) ** (2 * order)), circular)


def hpf(x, fc, order=2, circular=False):
    return _filt(x, lambda f: 1 / np.sqrt(1 + (fc / np.maximum(f, 1e-3)) ** (2 * order)), circular)


def bpf(x, lo, hi, order=2, circular=False):
    return _filt(x, lambda f: (1 / np.sqrt(1 + (f / hi) ** (2 * order))) *
                 (1 / np.sqrt(1 + (lo / np.maximum(f, 1e-3)) ** (2 * order))), circular)


def lp_var(x, fc):
    """One-pole lowpass with a time-varying cutoff (scalar or array)."""
    fc = np.broadcast_to(np.asarray(fc, float), x.shape)
    al = (1 - np.exp(-2 * np.pi * fc / SR)).tolist()
    xl = x.tolist()
    y = [0.0] * len(xl)
    s = 0.0
    for i in range(len(xl)):
        s += al[i] * (xl[i] - s)
        y[i] = s
    return np.array(y)


def crush(x, bits=8, div=1):
    m = np.max(np.abs(x))
    if m < 1e-9:
        return x
    x = x / m
    if div > 1:
        n = len(x)
        x = np.repeat(x[::div], div)[:n]
    q = 2 ** (bits - 1)
    return np.round(x * q) / q * m


# ---------------------------------------------------------------- reverb
_IR = {}


def make_ir(t, dark, seed):
    key = (round(t, 3), dark, seed)
    if key not in _IR:
        r = np.random.default_rng(seed)
        n = n_(t)
        x = lpf(r.normal(size=n), dark, circular=True)
        x = x * np.exp(-np.arange(n) / SR / (t / 6.0))
        k = n_(0.012)
        x[:k] *= np.linspace(0, 1, k)
        _IR[key] = x / np.sqrt(np.sum(x * x))
    return _IR[key]


def conv(x, ir):
    n = len(x) + len(ir) - 1
    N = 1 << int(np.ceil(np.log2(n)))
    return np.fft.irfft(np.fft.rfft(x, N) * np.fft.rfft(ir, N), N)[:n]


def reverb(x, t=1.0, wet=0.5, dark=3000, seed=1, circular=False, wet_only=False):
    y = conv(x, make_ir(t, dark, seed)) * wet
    if circular:
        y = wrap_tail(y, len(x))
        return y if wet_only else x + y
    if wet_only:
        return y
    out = np.zeros(max(len(x), len(y)))
    out[:len(x)] += x
    out[:len(y)] += y
    return out


# ---------------------------------------------------------------- output
def declick(x, a=0.0015, r=0.012):
    x = x.copy()
    na, nr = n_(a), min(n_(r), len(x) // 2)
    if na > 0:
        x[:na] *= np.linspace(0, 1, na)
    if nr > 0:
        x[-nr:] *= np.linspace(1, 0, nr)
    return x


def save(path, x):
    x = np.clip(x, -1.0, 1.0)
    data = np.ascontiguousarray((x * 32767.0).astype('<i2'))
    ch = 1 if x.ndim == 1 else x.shape[1]
    with wave.open(path, 'wb') as w:
        w.setnchannels(ch)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())
