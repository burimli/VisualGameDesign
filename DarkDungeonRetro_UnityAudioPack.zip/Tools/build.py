"""Render the whole pack.  usage: python3 build.py OUTPUT_DIR   (MUSIC_FORMAT=wav|ogg, default ogg)"""
import csv
import os
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np
from dsp import SR, declick, hpf, n_, norm, save
import music
import sfx

OUT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else 'UnityAudioPack')
MUSIC_FMT = os.environ.get('MUSIC_FORMAT', 'ogg').lower()
ROOT = os.path.join(OUT, 'Assets', 'Audio')
HAVE_FFMPEG = shutil.which('ffmpeg') is not None


def stats(x, loop):
    mono = x if x.ndim == 1 else x[:, 0]
    s = dict(dur=len(mono) / SR, peak=float(np.max(np.abs(x))), rms=float(np.sqrt(np.mean(x ** 2))),
             dc=float(abs(np.mean(x))), tail=float(np.sqrt(np.mean(mono[-n_(0.005):] ** 2))), seam=0.0)
    if loop:
        chans = [x] if x.ndim == 1 else [x[:, 0], x[:, 1]]
        s['seam'] = float(max(abs(c[0] - c[-1]) / (np.percentile(np.abs(np.diff(c)), 99) + 1e-9) for c in chans))
    return s


rows = []
t0 = time.time()
for folder, name, fn, peak, loop in sfx.REG + music.REG:
    x = np.nan_to_num(fn())
    # remove DC (pulse waves with duty != 0.5 carry an offset); circular for loops so seams stay clean
    if x.ndim == 1:
        x = hpf(x, 20, circular=loop)
    else:
        x = np.stack([hpf(x[:, 0], 20, circular=True), hpf(x[:, 1], 20, circular=True)], axis=1)
    if not loop and x.ndim == 1:
        x = declick(x)
    x = norm(x, peak)
    d = os.path.join(ROOT, folder)
    os.makedirs(d, exist_ok=True)
    as_ogg = folder == 'Music' and MUSIC_FMT == 'ogg' and HAVE_FFMPEG
    wav = os.path.join(d, name + '.wav')
    save(wav, x)
    ext = 'wav'
    if as_ogg:
        ogg = os.path.join(d, name + '.ogg')
        r = subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-c:a', 'libvorbis', '-q:a', '7', ogg])
        if r.returncode == 0:
            os.remove(wav)
            ext = 'ogg'
    s = stats(x, loop)
    rows.append(dict(folder=folder, name=name, ext=ext, loop=loop, **s))
    print(f"{folder + '/' + name:55s} {s['dur']:6.2f}s  peak {s['peak']:.2f}  rms {s['rms']:.3f}"
          f"{'  LOOP seam %.2f' % s['seam'] if loop else ''}", flush=True)

flags = []
for r in rows:
    if r['peak'] > 0.99:
        flags.append((r['name'], 'clipping'))
    if r['dc'] > 0.02:
        flags.append((r['name'], f"DC offset {r['dc']:.3f}"))
    if not r['loop'] and r['tail'] > 0.01:
        flags.append((r['name'], f"abrupt end {r['tail']:.3f}"))
    if r['loop'] and r['seam'] > 1.5:
        flags.append((r['name'], f"loop seam {r['seam']:.2f}"))
    if r['rms'] < 0.005:
        flags.append((r['name'], 'nearly silent'))

with open(os.path.join(OUT, 'AUDIO_LIST.csv'), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['file', 'seconds', 'loop', 'peak', 'rms'])
    for r in rows:
        w.writerow([f"Assets/Audio/{r['folder']}/{r['name']}.{r['ext']}", f"{r['dur']:.2f}",
                    'yes' if r['loop'] else 'no', f"{r['peak']:.2f}", f"{r['rms']:.3f}"])

print(f"\n{len(rows)} files in {time.time() - t0:.0f}s; {sum(r['loop'] for r in rows)} loops")
print('FLAGS:' if flags else 'No flags.')
for fl in flags:
    print('  ', fl)
