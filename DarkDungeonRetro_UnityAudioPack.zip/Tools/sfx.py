"""Sound-effect designs. Each function returns a mono float array; build.py normalises and saves it."""
from dsp import *
import numpy as np

REG = []


def add(folder, name, fn, peak=0.8, loop=False):
    REG.append((folder, name, fn, peak, loop))


PL, HZ, PZ, CO, EN, UI, AMB, STG = ('SFX/Player', 'SFX/Hazards', 'SFX/Puzzle', 'SFX/Collectibles',
                                    'SFX/Enemies', 'SFX/UI', 'Ambience', 'Music/Stingers')


# =====================================================================  PLAYER MOVEMENT
def _step(var):
    r = np.random.default_rng(500 + var)
    lp = r.uniform(650, 1100)
    f0 = r.uniform(85, 120)
    body = tone('sin', f0, f0 * 0.55, 0.12, decay=0.035)
    scuff = noise(0.14, decay=0.03, lp=lp, hp=150)
    grit = noise(0.08, decay=0.012, hp=2500, vol=0.25)
    return mix(body * 0.9, scuff, grit)


def jump():
    a = tone('sq', 150, 380, 0.2, decay=0.12, duty=0.25)
    b = tone('tri', 75, 190, 0.2, decay=0.12)
    air = noise(0.12, decay=0.05, hp=1200, vol=0.12)
    return crush(mix(a * 0.6, b * 0.8, air), 7)


def double_jump():
    a = tone('sq', 200, 520, 0.14, decay=0.08, duty=0.25)
    b = delay(tone('sq', 300, 760, 0.16, decay=0.09, duty=0.125), 0.07)
    return crush(mix(a * 0.6, b * 0.6, noise(0.2, decay=0.07, hp=1500, vol=0.12)), 7)


def land_soft():
    return mix(tone('sin', 90, 45, 0.15, decay=0.04), noise(0.15, decay=0.035, lp=800, hp=100, vol=0.7))


def land_hard():
    body = tone('sin', 75, 32, 0.3, decay=0.07)
    thud = noise(0.2, decay=0.05, lp=1100, hp=80)
    crack = noise(0.05, decay=0.01, hp=2000, vol=0.35)
    debris = delay(noise(0.35, decay=0.1, lp=2500, hp=500, vol=0.2), 0.04)
    return reverb(mix(body * 1.1, thud, crack, debris), 0.5, 0.35, 2000)


def land_heavy():
    body = tone('sin', 58, 26, 0.55, decay=0.14)
    thud = noise(0.3, decay=0.09, lp=700, hp=60)
    crack = noise(0.08, decay=0.02, hp=1500, vol=0.4)
    rubble = delay(noise(0.6, decay=0.18, lp=3000, hp=400, vol=0.25), 0.05)
    return reverb(mix(body * 1.2, thud, crack, rubble), 0.9, 0.5, 1800)


def wall_slide_loop():
    n = n_(1.0)
    t = np.arange(n) / SR
    x = nrm(bpf(rng.uniform(-1, 1, n), 400, 2600, circular=True))
    x = x * (0.7 + 0.3 * np.sin(2 * np.pi * 7 * t)) * (0.8 + 0.2 * np.sin(2 * np.pi * 3 * t + 1))
    return x * 0.8 + np.sin(2 * np.pi * 70 * t) * 0.15


def wall_grab():
    return mix(noise(0.12, decay=0.03, hp=1200, lp=5000, vol=0.7), tone('sin', 130, 70, 0.14, decay=0.04))


def dash():
    n = noise(0.3, a=0.03, decay=0.12)
    k = n_(0.08)
    fc = np.concatenate([np.linspace(500, 4500, k), np.linspace(4500, 400, len(n) - k)])
    w = nrm(lp_var(lp_var(n, fc), fc))
    return crush(mix(w * 1.2, tone('sq', 320, 110, 0.28, decay=0.1, duty=0.25, vol=0.25)), 8)


def dash_ready():
    a = tone('sq', 440, 440, 0.06, duty=0.25, decay=0.04)
    b = delay(tone('sq', 659, 659, 0.1, duty=0.25, decay=0.06), 0.06)
    return mix(a, b) * 0.6


def ledge_grab():
    cloth = noise(0.15, a=0.01, decay=0.05, lp=2500, hp=300, vol=0.6)
    thump = tone('sin', 110, 60, 0.15, decay=0.04)
    tick = delay(noise(0.04, decay=0.01, hp=2500, vol=0.3), 0.01)
    return mix(cloth, thump, tick)


def ledge_climb():
    sc = noise(0.4, a=0.02, decay=0.25, lp=2000, hp=300, vol=0.9)
    sc = nrm(lp_var(sc, np.linspace(500, 1800, len(sc)))) * 0.7
    th1 = delay(tone('sin', 100, 55, 0.12, decay=0.035), 0.28)
    th2 = delay(tone('sin', 90, 50, 0.12, decay=0.035, vol=0.7), 0.42)
    return mix(sc, th1, th2)


def climb_loop():
    buf = np.zeros(n_(0.6))
    for p, g, f in [(0.0, 1.0, 1500), (0.3, 0.85, 1250)]:
        c = mix(noise(0.07, decay=0.02, hp=f, lp=f * 2.5), tone('tri', 260, 190, 0.1, decay=0.03, vol=0.3))
        place(buf, c, p, g, wrap=True)
    return buf


def slide():
    n = noise(0.5, a=0.02, decay=0.3)
    s = nrm(lp_var(n, np.linspace(2200, 600, len(n))))
    return mix(s, tone('sin', 60, 50, 0.5, decay=0.3, vol=0.3))


def skid():
    sq = tone('sq', 900, 560, 0.2, decay=0.08, duty=0.125, vol=0.2)
    return crush(mix(sq, noise(0.2, decay=0.07, hp=1800, lp=6000, vol=0.5)), 7)


# =====================================================================  PLAYER STATE
def hurt():
    a = tone('sq', 320, 120, 0.25, decay=0.12, vib=30, vibdepth=0.05)
    b = noise(0.15, decay=0.04, hp=800, lp=4000, vol=0.5)
    th = tone('sin', 90, 45, 0.2, decay=0.06, vol=0.8)
    return crush(mix(a * 0.7, b, th), 6, 2)


def death():
    d = 1.1
    t = tt(d)
    f = fcurve(440, 45, d) * (1 + 0.03 * np.sin(2 * np.pi * 9 * t))
    x1 = osc('sq', f, 0.5) * env(d, a=0.005, decay=0.5, r=0.2) * 0.5
    x2 = osc('saw', fcurve(220, 30, d)) * env(d, a=0.005, decay=0.45, r=0.2) * 0.4
    n = noise(0.5, decay=0.15, lp=1500, vol=0.5)
    x = crush(mix(x1, x2, n), 6, 2)
    boom = delay(tone('sin', 80, 28, 0.6, decay=0.18), 0.85)
    return reverb(mix(x, boom), 1.2, 0.5, 1800)


def respawn():
    seq = [220, 261.63, 329.63, 440, 659.26]
    parts = [nt('sq', f, 0.065 * i, 0.12, 0.45, duty=0.25, decay=0.08) for i, f in enumerate(seq)]
    swell = tone('sin', 55, 110, 0.5, a=0.15, decay=0.4, vol=0.6)
    return reverb(mix(*parts, swell), 1.0, 0.8, 3500)


def low_health_heartbeat_loop():
    buf = np.zeros(n_(1.0))
    beat = lambda: mix(tone('sin', 62, 38, 0.15, decay=0.05), noise(0.1, decay=0.02, lp=400, vol=0.3))
    place(buf, beat(), 0.0, 1.0, wrap=True)
    place(buf, beat(), 0.24, 0.7, wrap=True)
    return buf


def fall_pit():
    d = 1.3
    f = fcurve(1000, 80, d) * (1 + 0.02 * np.sin(2 * np.pi * 7 * tt(d)))
    return lpf(osc('tri', f) * env(d, a=0.02, decay=0.9, r=0.35) * 0.7, 2500)


# =====================================================================  HAZARDS
def spike_extend():
    return mix(noise(0.08, decay=0.02, hp=3000, vol=0.7),
               tone('sq', 1500, 800, 0.07, decay=0.025, duty=0.125, vol=0.3),
               tone('sin', 140, 70, 0.12, decay=0.03, vol=0.8))


def spike_retract():
    return mix(noise(0.22, a=0.08, decay=0.09, hp=1500, lp=6000, vol=0.5),
               tone('tri', 500, 900, 0.18, decay=0.08, vol=0.3))


def spike_hit():
    a = noise(0.14, decay=0.04, lp=1800, hp=200, vol=0.8)
    b = tone('sq', 220, 90, 0.18, decay=0.06, duty=0.25, vol=0.4)
    return crush(mix(a, b, tone('sin', 100, 50, 0.2, decay=0.05)), 7)


def saw_loop():
    n = n_(1.0)
    t = np.arange(n) / SR
    s1 = 2 * ((110 * t) % 1) - 1
    s2 = 2 * ((164 * t) % 1) - 1
    buzz = nrm(bpf(rng.uniform(-1, 1, n), 2500, 7000, circular=True)) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 55 * t)))
    x = (s1 * 0.5 + s2 * 0.3) * (0.75 + 0.25 * np.sin(2 * np.pi * 4 * t)) + buzz * 0.35
    return lpf(x, 4500, circular=True)


def saw_hit():
    a = tone('sq', 1100, 320, 0.3, decay=0.1, duty=0.25, vol=0.35, vib=40, vibdepth=0.08)
    b = noise(0.25, decay=0.07, hp=2000, vol=0.6)
    c = tone('sin', 120, 60, 0.15, decay=0.04)
    return reverb(crush(mix(a, b, c), 7), 0.5, 0.4, 4000)


def pendulum_whoosh():
    d = 0.9
    n = noise(d, a=0.05, flat=True)
    g = np.exp(-((tt(d) - 0.45) / 0.18) ** 2)
    fc = 250 + 2600 * g
    w = nrm(lp_var(lp_var(n, fc), fc)) * g
    thrum = osc('sin', fcurve(55, 70, d, 'lin')) * g * 0.3
    return mix(w * 1.3, thrum)


def fire_jet():
    d = 0.9
    base = noise(d, a=0.06, flat=True, r=0.25)
    f = nrm(lp_var(base, np.linspace(1800, 3000, len(base))))
    f = f * (0.8 + 0.2 * np.sin(2 * np.pi * 23 * tt(d)))
    crack = np.zeros(n_(d))
    r = np.random.default_rng(77)
    for p in r.uniform(0.05, 0.7, 8):
        place(crack, noise(0.015, decay=0.004, hp=1500, vol=0.7), p)
    return mix(f, crack * 0.5, tone('sin', 70, 60, d, decay=0.5, vol=0.2))


def arrow_launch():
    tw = tone('tri', 1400, 320, 0.22, decay=0.06, vib=55, vibdepth=0.04, vol=0.5)
    return mix(tw, noise(0.25, a=0.01, decay=0.06, hp=1200, vol=0.5), tone('sin', 160, 80, 0.1, decay=0.03, vol=0.5))


def arrow_impact():
    a = noise(0.1, decay=0.025, lp=1800, hp=150)
    b = tone('sin', 190, 85, 0.15, decay=0.04)
    c = tone('tri', 640, 600, 0.35, decay=0.12, vib=38, vibdepth=0.03, vol=0.22)
    return mix(a * 0.8, b, c)


def platform_crack():
    buf = np.zeros(n_(0.4))
    for p, g, f in [(0, 1.0, 1200), (0.08, 0.8, 1800), (0.2, 1.0, 1000)]:
        place(buf, mix(noise(0.07, decay=0.012, hp=f, lp=7000), tone('sq', 300, 120, 0.05, decay=0.015, vol=0.2)), p, g)
    return buf


def _debris(buf, r, count, span, lo=500, hi=2500, tau=0.5):
    for p in np.sort(r.uniform(0, span, count)):
        place(buf, noise(0.03, decay=r.uniform(0.005, 0.012), hp=r.uniform(lo, hi), lp=7000),
              p, r.uniform(0.3, 1.0) * np.exp(-p / tau))
    return buf


def platform_crumble():
    d = 1.1
    n = noise(d, a=0.05, decay=0.5, lp=900, hp=60) * (0.7 + 0.3 * np.sin(2 * np.pi * 14 * tt(d)))
    buf = _debris(np.zeros(n_(d)), np.random.default_rng(31), 22, 0.9, 600, 2000, 0.6)
    return mix(n * 1.2, buf * 0.6)


def platform_crash():
    th = tone('sin', 70, 28, 0.6, decay=0.15)
    n1 = noise(0.8, decay=0.22, lp=2500, hp=100, vol=0.8)
    buf = _debris(np.zeros(n_(1.0)), np.random.default_rng(32), 25, 0.8, 500, 2500, 0.4)
    return reverb(mix(th * 1.2, n1, buf * 0.6), 0.8, 0.5, 2000)


def boulder_roll_loop():
    L = 1.5
    n = n_(L)
    t = np.arange(n) / SR
    x = nrm(lpf(rng.uniform(-1, 1, n), 260, circular=True))
    x = x * (0.6 + 0.25 * np.sin(2 * np.pi * (5 / L) * t) + 0.15 * np.sin(2 * np.pi * (8 / L) * t + 1))
    buf = x + np.sin(2 * np.pi * 40 * t) * 0.35
    r = np.random.default_rng(9)
    for p in r.uniform(0, L, 14):
        place(buf, noise(0.025, decay=0.006, lp=1800, hp=300, vol=0.3), p, wrap=True)
    return buf


def gas_bubble_loop():
    L = 2.0
    n = n_(L)
    hiss = nrm(bpf(rng.uniform(-1, 1, n), 300, 1400, circular=True)) * 0.2
    r = np.random.default_rng(10)
    buf = hiss.copy()
    for p in r.uniform(0, L, 16):
        f0 = r.uniform(180, 320)
        place(buf, tone('sin', f0, f0 * r.uniform(1.8, 2.6), 0.08, decay=0.025), p, r.uniform(0.3, 0.8), wrap=True)
    return buf


def electric_hum_loop():
    n = n_(1.0)
    t = np.arange(n) / SR
    h = np.sin(2 * np.pi * 100 * t) * 0.5 + (2 * ((200 * t) % 1) - 1) * 0.15 + np.sin(2 * np.pi * 300 * t) * 0.15
    buf = h * (0.85 + 0.15 * np.sin(2 * np.pi * 3 * t))
    r = np.random.default_rng(11)
    for p in r.uniform(0, 1.0, 12):
        place(buf, noise(0.02, decay=0.005, hp=3000, vol=0.5), p, r.uniform(0.2, 0.7), wrap=True)
    return buf


def zap():
    d = 0.3
    r = np.random.default_rng(12)
    steps = r.uniform(300, 2600, int(d / 0.006) + 2)
    f = np.repeat(steps, n_(0.006))[:n_(d)]
    x = osc('sq', f, 0.5) * env(d, a=0.001, decay=0.1) * 0.4
    return crush(mix(x, noise(d, decay=0.08, hp=2000, vol=0.7)), 7)


def pressure_plate():
    return mix(tone('sin', 160, 70, 0.15, decay=0.04), noise(0.03, decay=0.008, hp=2000, vol=0.5),
               delay(noise(0.12, a=0.01, decay=0.04, lp=1500, hp=200, vol=0.4), 0.03))


# =====================================================================  PUZZLE
def lever_pull():
    buf = np.zeros(n_(0.5))
    for i, p in enumerate([0.0, 0.07, 0.14]):
        place(buf, mix(noise(0.03, decay=0.008, hp=2200, vol=0.6),
                       tone('tri', 700 + i * 80, 600 + i * 80, 0.04, decay=0.012, vol=0.4)), p)
    place(buf, mix(tone('sin', 115, 58, 0.2, decay=0.06), noise(0.15, decay=0.04, lp=1000, vol=0.6)), 0.24)
    return buf


def switch_toggle():
    a = mix(noise(0.02, decay=0.005, hp=2500, vol=0.6), tone('tri', 900, 700, 0.03, decay=0.01, vol=0.4))
    b = delay(mix(noise(0.03, decay=0.008, lp=2500, hp=300, vol=0.6), tone('sin', 130, 70, 0.08, decay=0.025)), 0.06)
    return mix(a, b)


def button_press():
    return mix(tone('sq', 220, 110, 0.08, decay=0.025, duty=0.25, vol=0.4),
               noise(0.04, decay=0.01, lp=3000, hp=300, vol=0.5), tone('sin', 120, 70, 0.1, decay=0.03))


def _grind(d, lo=300, hi=700, rough=24):
    n = noise(d, a=0.1, flat=True, r=0.15)
    t = tt(d)
    fc = lo + (hi - lo) * (0.5 + 0.5 * np.sin(2 * np.pi * 1.3 * t))
    g = nrm(lp_var(lp_var(n, fc), fc))
    return g * (0.65 + 0.35 * np.sin(2 * np.pi * rough * t + 2 * np.sin(2 * np.pi * 3 * t)))


def door_stone_open():
    d = 1.6
    g = _grind(d)
    rumble = tone('sin', 52, 48, d, a=0.15, flat=True, r=0.2, vol=0.5)
    grit = noise(d, a=0.1, flat=True, r=0.2, hp=1500, lp=4000, vol=0.08)
    return reverb(mix(g * 1.2, rumble, grit), 1.0, 0.5, 1800)


def door_stone_close():
    d = 1.3
    g = _grind(d)
    rumble = tone('sin', 48, 50, d, a=0.1, flat=True, r=0.05, vol=0.5)
    boom = delay(mix(tone('sin', 65, 28, 0.5, decay=0.12), noise(0.4, decay=0.1, lp=1200, hp=60, vol=0.8)), 1.25)
    return reverb(mix(g * 1.2, rumble, boom), 1.0, 0.5, 1800)


def _creak(d, f_lo, f_hi, seed=1):
    t = tt(d)
    r = np.random.default_rng(seed)
    f = f_lo + (f_hi - f_lo) * np.sin(np.pi * t / d) + 12 * np.sin(2 * np.pi * r.uniform(8, 14) * t)
    x = lpf(osc('saw', f), 1300) * env(d, a=0.08, flat=True, r=0.25)
    return x * (0.6 + 0.4 * np.sin(2 * np.pi * 5 * t + r.uniform(0, 3)))


def door_wood_open():
    c = _creak(0.9, 150, 240, 2)
    return reverb(mix(c * 0.5, noise(0.9, a=0.05, flat=True, r=0.2, hp=800, lp=3000, vol=0.15)), 0.6, 0.3, 2500)


def door_wood_close():
    c = _creak(0.5, 240, 150, 3)
    thud = delay(mix(tone('sin', 100, 50, 0.2, decay=0.06), noise(0.15, decay=0.04, lp=1000, vol=0.7)), 0.45)
    return reverb(mix(c * 0.5, thud), 0.6, 0.35, 2500)


def _chain(d, rate0, rate1, seed=44):
    buf = np.zeros(n_(d))
    r = np.random.default_rng(seed)
    t = 0.0
    while t < d - 0.05:
        f = r.uniform(1800, 3200)
        c = mix(tone('tri', f, f * 0.97, 0.05, decay=0.015, vol=0.5), noise(0.03, decay=0.006, hp=3000, vol=0.4))
        place(buf, c, t, r.uniform(0.5, 1.0))
        t += 1.0 / (rate0 + (rate1 - rate0) * (t / d))
    return buf


def gate_raise():
    d = 1.5
    return reverb(mix(_chain(d, 12, 18) * 0.8, _grind(d, 200, 450) * 0.8,
                      tone('sin', 60, 60, d, a=0.1, flat=True, r=0.2, vol=0.4)), 0.8, 0.4, 2500)


def gate_lower():
    d = 1.2
    clang = delay(mix(tone('sq', 320, 300, 0.4, decay=0.15, duty=0.25, vol=0.3),
                      noise(0.3, decay=0.06, hp=1500, vol=0.6), tone('sin', 70, 30, 0.5, decay=0.12)), 1.15)
    return reverb(mix(_chain(d, 18, 12, 45) * 0.8, _grind(d, 200, 450) * 0.8, clang), 0.8, 0.4, 2500)


def key_pickup():
    return reverb(mix(bell(659.26, 0.6, 0.7, 0.2), delay(bell(783.99, 0.8, 0.7, 0.3), 0.07)), 0.9, 0.7, 4000)


def key_use():
    sc = noise(0.2, a=0.02, decay=0.08, hp=1500, lp=5000, vol=0.4)
    click = delay(mix(noise(0.03, decay=0.008, hp=2000, vol=0.6), tone('tri', 1200, 900, 0.05, decay=0.012, vol=0.3)), 0.2)
    th = delay(tone('sin', 120, 60, 0.12, decay=0.035, vol=0.8), 0.22)
    return mix(sc, click, th)


def lock_unlock():
    buf = np.zeros(n_(0.6))
    for p in [0.0, 0.1]:
        place(buf, mix(noise(0.03, decay=0.007, hp=2500, vol=0.7), tone('tri', 1100, 800, 0.05, decay=0.012, vol=0.4)), p)
    place(buf, mix(tone('sin', 130, 55, 0.25, decay=0.07), noise(0.2, decay=0.05, lp=1500, hp=200, vol=0.6),
                   tone('sq', 400, 200, 0.1, decay=0.03, duty=0.25, vol=0.2)), 0.22)
    return buf


def block_scrape_loop():
    n = n_(1.0)
    t = np.arange(n) / SR
    x = nrm(bpf(rng.uniform(-1, 1, n), 150, 1100, circular=True))
    x = x * (0.65 + 0.35 * np.sin(2 * np.pi * 6 * t + 0.8 * np.sin(2 * np.pi * 2 * t)))
    saw = lpf(2 * ((55 * t) % 1) - 1, 300, circular=True) * 0.35
    return x * 1.2 + saw


def block_thud():
    a = tone('sin', 85, 38, 0.3, decay=0.09)
    b = noise(0.2, decay=0.06, lp=800, hp=60, vol=0.9)
    dust = delay(noise(0.3, a=0.02, decay=0.1, lp=3000, hp=700, vol=0.2), 0.03)
    return reverb(mix(a * 1.1, b, dust), 0.4, 0.3, 2000)


def moving_platform_loop():
    n = n_(2.0)
    t = np.arange(n) / SR
    hum = lpf(2 * ((55 * t) % 1) - 1, 380, circular=True) * 0.5
    gear = nrm(lpf(rng.uniform(-1, 1, n), 320, circular=True)) * 0.35
    buf = hum + gear
    for k in range(8):
        place(buf, mix(noise(0.03, decay=0.007, lp=2500, hp=400, vol=0.5), tone('sin', 140, 90, 0.06, decay=0.02, vol=0.4)),
              k * 0.25, 0.7 if k % 2 else 1.0, wrap=True)
    return buf


def teleport():
    d = 0.9
    t = tt(d)
    r = np.random.default_rng(13)
    steps = np.repeat(r.uniform(0, 1, int(d / 0.025) + 2), n_(0.025))[:n_(d)]
    f = 180 * (9 ** (t / d)) * (0.85 + 0.3 * steps)
    x = osc('sq', f, 0.25) * env(d, a=0.01, decay=0.5, r=0.2) * 0.5
    sw = nrm(lp_var(noise(d, a=0.02, decay=0.5, r=0.2), np.linspace(300, 6000, n_(d)))) * 0.6
    thr = tone('sin', 60, 220, d, decay=0.6, vol=0.5)
    return reverb(crush(mix(x, sw, thr), 7, 2), 1.2, 0.8, 4500)


def puzzle_solved():
    seq = [(220, 0.0), (261.63, 0.1), (329.63, 0.2), (440, 0.3)]
    parts = [nt('sq', f, p, 0.18, 0.4, duty=0.25, decay=0.09) for f, p in seq]
    chord = delay(mix(*[bell(f, 1.2, 0.6, 0.5) for f in (440.0, 554.37, 659.26)]), 0.42)
    bass = delay(tone('tri', 110, 110, 1.2, decay=0.6, vol=0.8), 0.42)
    return reverb(mix(*parts, chord, bass), 1.6, 0.9, 3500)


def puzzle_wrong():
    a = tone('sq', 110, 90, 0.35, decay=0.2, vol=0.4)
    b = tone('sq', 116.5, 95, 0.35, decay=0.2, vol=0.4)
    c = tone('sq', 155.6, 125, 0.35, decay=0.2, duty=0.25, vol=0.2)
    return crush(mix(a, b, c), 6)


def timer_tick():
    return mix(noise(0.04, decay=0.008, hp=3000, vol=0.6), tone('tri', 1100, 900, 0.05, decay=0.012, vol=0.5))


def timer_tock():
    return mix(noise(0.04, decay=0.008, hp=2000, vol=0.6), tone('tri', 780, 640, 0.05, decay=0.012, vol=0.5))


def timer_expired():
    a = tone('sq', 220, 110, 0.8, decay=0.4, duty=0.25, vol=0.4)
    b = tone('sq', 233, 117, 0.8, decay=0.4, duty=0.25, vol=0.4)
    return reverb(crush(mix(a, b, tone('sin', 80, 40, 0.6, decay=0.2)), 6), 1.0, 0.4, 2000)


def secret_reveal():
    g = _grind(0.8, 200, 450) * 0.9
    rumble = tone('sin', 50, 55, 0.8, a=0.1, flat=True, r=0.1, vol=0.4)
    chime = delay(mix(bell(523.25, 1.4, 0.5, 0.6), bell(783.99, 1.4, 0.4, 0.6), bell(1046.5, 1.4, 0.25, 0.6)), 0.7)
    return reverb(mix(g, rumble, chime), 1.8, 0.8, 3500)


# =====================================================================  COLLECTIBLES
def coin(step=0):
    s = 2 ** (step / 12)
    a = tone('sq', 659.26 * s, 659.26 * s, 0.05, duty=0.125, decay=0.04, vol=0.5)
    b = delay(tone('sq', 987.77 * s, 987.77 * s, 0.18, duty=0.125, decay=0.09, vol=0.5), 0.05)
    return mix(a, b)


def gem_pickup():
    return reverb(mix(bell(784, 0.9, 0.7, 0.35), delay(bell(1174.7, 0.9, 0.5, 0.4), 0.08)), 1.1, 0.8, 4500)


def powerup_pickup():
    notes = [220, 261.63, 329.63, 392, 440, 523.25, 659.26, 880]
    parts = [nt('sq', f, i * 0.045, 0.09, 0.4, duty=0.25, decay=0.06) for i, f in enumerate(notes)]
    return reverb(crush(mix(*parts, tone('sin', 55, 110, 0.45, decay=0.3, vol=0.5)), 8), 0.8, 0.5, 3500)


def powerup_activate():
    d = 0.9
    sw = tone('saw', 70, 300, d, a=0.05, decay=0.5, r=0.3, vol=0.4)
    nz = nrm(lp_var(noise(d, a=0.1, decay=0.5, r=0.3), np.linspace(200, 5000, n_(d)))) * 0.6
    hit = delay(mix(tone('sin', 110, 40, 0.4, decay=0.1), tone('sq', 440, 880, 0.1, duty=0.25, decay=0.05, vol=0.3)), 0.5)
    return reverb(crush(mix(sw, nz, hit), 7), 1.0, 0.5, 3000)


def checkpoint():
    ign = nrm(lp_var(noise(0.5, a=0.1, decay=0.2, r=0.15), np.linspace(400, 2500, n_(0.5)))) * 0.5
    notes = [293.66, 349.23, 440.0]
    b = [delay(bell(f, 1.0, 0.7, 0.4), 0.12 * i) for i, f in enumerate(notes)]
    return reverb(mix(ign, *b), 1.3, 0.9, 3500)


def star_ding(i):
    f = [587.33, 698.46, 880.0][i]
    sp = noise(0.15, decay=0.04, hp=5000, vol=0.15)
    return reverb(mix(bell(f, 0.9, 0.8, 0.4), sp), 1.2, 0.8, 4500)


def achievement():
    notes = [(440, 0.0), (523.25, 0.08), (659.26, 0.16), (880, 0.24), (659.26, 0.34), (880, 0.42), (1046.5, 0.5)]
    parts = [nt('sq', f, p, 0.16, 0.3, duty=0.125, decay=0.1) for f, p in notes]
    ch = delay(mix(*[bell(f, 1.4, 0.5, 0.6) for f in (880, 1046.5, 1318.5)]), 0.5)
    return reverb(mix(*parts, ch, delay(tone('tri', 110, 110, 1.2, decay=0.6, vol=0.7), 0.5)), 1.6, 0.9, 4000)


# =====================================================================  ENEMIES
def enemy_idle_growl():
    d = 1.1
    t = tt(d)
    f = fcurve(75, 52, d, 'lin') * (1 + 0.02 * np.sin(2 * np.pi * 5 * t))
    x = lpf(osc('saw', f) * (0.5 + 0.5 * np.sin(2 * np.pi * 38 * t)), 700)
    n = noise(d, lp=500, a=0.15, flat=True, r=0.35, vol=0.4)
    return reverb(mix(nrm(x) * env(d, a=0.15, flat=True, r=0.35), n), 0.5, 0.3, 1500)


def enemy_alert():
    d = 0.35
    f = fcurve(600, 1500, d, 'lin') * (1 + 0.04 * np.sin(2 * np.pi * 28 * tt(d)))
    x = osc('sq', f, 0.25) * env(d, a=0.01, decay=0.2, r=0.08) * 0.5
    return crush(mix(x, noise(0.3, decay=0.08, hp=1500, vol=0.4)), 6)


def enemy_attack():
    sw = nrm(lp_var(noise(0.25, a=0.02, decay=0.08), np.linspace(600, 4500, n_(0.25))))
    a = tone('sq', 520, 140, 0.25, decay=0.07, duty=0.25, vol=0.3)
    return crush(mix(sw, a, delay(tone('sin', 100, 50, 0.12, decay=0.035), 0.08)), 7)


def enemy_hit():
    a = noise(0.14, decay=0.04, lp=2500, hp=200, vol=0.8)
    b = tone('sq', 200, 80, 0.2, decay=0.07, duty=0.25, vol=0.4)
    return crush(mix(a, b, tone('sin', 120, 55, 0.2, decay=0.05)), 6)


def enemy_death():
    d = 1.0
    f = fcurve(260, 40, d) * (1 + 0.04 * np.sin(2 * np.pi * 14 * tt(d)))
    x = osc('saw', f) * env(d, a=0.01, decay=0.5, r=0.3) * 0.5
    n = nrm(lp_var(noise(d, a=0.01, decay=0.4, r=0.3), fcurve(3000, 300, d))) * 0.6
    return reverb(crush(mix(x, n), 5, 2), 0.9, 0.5, 2000)


def boss_intro():
    d = 4.0
    t = tt(d)
    fl = lambda f: np.full(n_(d), f)
    drone = osc('saw', fl(41.2)) + osc('saw', fl(43.65)) * 0.9 + osc('saw', fl(61.74)) * 0.6
    drone = lpf(drone, 500) * env(d, a=1.5, flat=True, r=1.0) * 0.5
    boom = mix(tone('sin', 70, 25, 1.8, decay=0.5), noise(1.5, decay=0.35, lp=900, hp=40, vol=0.8))
    swell = nrm(lp_var(noise(d, a=2.0, flat=True, r=0.8), np.linspace(150, 3000, n_(d)))) * 0.35 * (t / d)
    return reverb(mix(drone, swell, delay(boom, 1.8)), 2.2, 0.7, 1800)


def boss_phase_change():
    d = 2.0
    roar = osc('saw', fcurve(70, 150, d) * (1 + 0.03 * np.sin(2 * np.pi * 24 * tt(d))))
    roar = lpf(roar, 900) * env(d, a=0.05, decay=0.9, r=0.3) * 0.8
    rise = nrm(lp_var(noise(1.2, a=0.1, decay=0.7, r=0.1), np.linspace(300, 5000, n_(1.2)))) * 0.6
    hit = delay(mix(tone('sin', 90, 28, 0.8, decay=0.2), noise(0.6, decay=0.15, lp=1500, hp=60, vol=0.8)), 1.2)
    return reverb(crush(mix(roar, rise, hit), 7), 1.5, 0.6, 2200)


def boss_defeat():
    r = np.random.default_rng(14)
    bursts = np.zeros(n_(3.2))
    for p in [0.0, 0.3, 0.55, 0.9, 1.4]:
        place(bursts, mix(noise(0.8, decay=0.2, lp=r.uniform(1200, 3000), hp=60, vol=0.8),
                          tone('sin', 90, 28, 0.6, decay=0.14)), p, 1.0 - p * 0.3)
    desc = lpf(tone('saw', 330, 30, 3.0, a=0.02, decay=1.2, r=0.4, vol=0.4, vib=6, vibdepth=0.03), 1500)
    final = delay(mix(tone('sin', 60, 22, 1.2, decay=0.4), noise(1.0, decay=0.3, lp=800, hp=40, vol=0.8)), 1.8)
    return reverb(crush(mix(bursts, desc, final), 7), 2.0, 0.6, 2000)


# =====================================================================  UI
def ui_hover():
    return tone('tri', 660, 660, 0.05, decay=0.02, vol=0.5)


def ui_select():
    return mix(nt('sq', 440, 0, 0.06, 0.4, duty=0.25, decay=0.04), nt('sq', 587.33, 0.05, 0.08, 0.4, duty=0.25, decay=0.05))


def ui_confirm():
    return mix(nt('sq', 440, 0, 0.08, 0.4, duty=0.25, decay=0.05), nt('sq', 587.33, 0.07, 0.14, 0.4, duty=0.25, decay=0.08),
               nt('tri', 880, 0.07, 0.14, 0.2, decay=0.08))


def ui_back():
    return mix(nt('sq', 587.33, 0, 0.08, 0.4, duty=0.25, decay=0.05), nt('sq', 440, 0.07, 0.14, 0.4, duty=0.25, decay=0.08))


def ui_pause():
    return lpf(mix(nt('sq', 330, 0, 0.12, 0.4, duty=0.25, decay=0.07), nt('sq', 220, 0.09, 0.18, 0.4, duty=0.25, decay=0.1)), 2000)


def ui_unpause():
    return lpf(mix(nt('sq', 220, 0, 0.12, 0.4, duty=0.25, decay=0.07), nt('sq', 330, 0.09, 0.18, 0.4, duty=0.25, decay=0.1)), 2000)


def ui_error():
    one = lambda: mix(tone('sq', 110, 105, 0.09, decay=0.05, vol=0.4), tone('sq', 116.5, 110, 0.09, decay=0.05, vol=0.4))
    return crush(mix(one(), delay(one(), 0.12)), 6)


def ui_tab():
    return mix(tone('tri', 880, 880, 0.04, decay=0.015, vol=0.4), noise(0.02, decay=0.005, hp=3000, vol=0.3))


def ui_slider_tick():
    return tone('tri', 1000, 1000, 0.03, decay=0.01, vol=0.35)


def stinger_game_start():
    boom = mix(tone('sin', 80, 30, 1.2, decay=0.3), noise(0.8, decay=0.2, lp=900, hp=40, vol=0.7))
    notes = [110, 164.81, 220, 261.63, 329.63]
    arp = [nt('saw', f, 0.35 + i * 0.12, 0.2, 0.3, decay=0.12) for i, f in enumerate(notes)]
    ch = delay(mix(*[bell(f, 1.4, 0.5, 0.7) for f in (220, 261.63, 329.63)]), 0.95)
    return reverb(crush(mix(boom, lpf(mix(*arp), 2500), ch), 8), 1.8, 0.7, 2500)


def stinger_game_over():
    notes = [440, 415.3, 392, 370, 349.23, 329.63]
    parts = [nt('saw', f, i * 0.35, 0.6, 0.3, decay=0.4, vib=5) for i, f in enumerate(notes)]
    drone = tone('sin', 55, 50, 2.6, a=0.3, decay=1.5, vol=0.6)
    return reverb(crush(mix(lpf(mix(*parts), 1600), drone), 7), 2.0, 0.8, 1800)


def stinger_level_complete():
    mel = [(220, 0.0, 0.14), (261.63, 0.14, 0.14), (329.63, 0.28, 0.14), (440, 0.42, 0.14),
           (329.63, 0.56, 0.14), (440, 0.7, 0.14), (554.37, 0.84, 0.3), (659.26, 1.14, 1.0)]
    m = [nt('sq', f, s, dd + 0.2, 0.35, duty=0.25, decay=0.18) for f, s, dd in mel]
    ch = delay(mix(*[bell(f, 1.8, 0.5, 0.8) for f in (440, 554.37, 659.26)]), 0.84)
    bass = delay(tone('tri', 110, 110, 1.8, decay=0.9, vol=0.8), 0.84)
    return reverb(mix(*m, ch, bass), 1.8, 0.9, 3500)


def stinger_level_fail():
    mel = [(329.63, 0.0, 0.3), (261.63, 0.35, 0.3), (220, 0.7, 0.35), (110, 1.1, 1.2)]
    p = [nt('saw', f, s, dd + 0.2, 0.3, decay=0.3, vib=5) for f, s, dd in mel]
    drone = tone('sin', 55, 50, 2.0, a=0.2, decay=1.0, vol=0.6)
    return reverb(crush(mix(lpf(mix(*p), 1500), drone), 7), 1.8, 0.8, 2000)


# =====================================================================  AMBIENCE (loops + one-shots)
def amb_room_tone_loop():
    L = 8.0
    n = n_(L)
    t = np.arange(n) / SR
    base = nrm(lpf(rng.uniform(-1, 1, n), 160, circular=True)) * 0.6
    drone = np.sin(2 * np.pi * 55 * t) * 0.4 + np.sin(2 * np.pi * 82 * t + 1) * 0.2 + np.sin(2 * np.pi * 58 * t + 2) * 0.1
    drone = drone * (0.8 + 0.2 * np.sin(2 * np.pi * (1 / L) * t))
    hiss = nrm(bpf(rng.uniform(-1, 1, n), 1800, 5000, circular=True)) * 0.04 * (0.6 + 0.4 * np.sin(2 * np.pi * (3 / L) * t + 0.7))
    return base + drone + hiss


def amb_drips_loop():
    L = 10.0
    n = n_(L)
    r = np.random.default_rng(21)
    buf = np.zeros(n)
    for p in np.sort(r.uniform(0, L, 9)):
        f = r.uniform(900, 1700)
        v = r.uniform(0.35, 0.9)
        dr = tone('sin', f * 0.75, f * 1.35, 0.07, decay=0.018)
        place(buf, dr, p, v, wrap=True)
        place(buf, dr, p + r.uniform(0.18, 0.32), v * 0.3, wrap=True)
    wet = reverb(buf, 2.0, 0.9, 3000, seed=3, circular=True)
    return wet + nrm(lpf(rng.uniform(-1, 1, n), 140, circular=True)) * 0.1


def amb_wind_loop():
    L = 10.0
    n = n_(L)
    t = np.arange(n) / SR
    a = nrm(bpf(rng.uniform(-1, 1, n), 120, 600, circular=True))
    b = nrm(bpf(rng.uniform(-1, 1, n), 500, 1800, circular=True))
    ma = 0.55 + 0.25 * np.sin(2 * np.pi * (1 / L) * t) + 0.2 * np.sin(2 * np.pi * (3 / L) * t + 1.3)
    mb = 0.3 + 0.3 * np.sin(2 * np.pi * (2 / L) * t + 0.4) ** 2
    return a * ma * 0.8 + b * mb * 0.35


def amb_torch_loop():
    L = 6.0
    n = n_(L)
    t = np.arange(n) / SR
    r = np.random.default_rng(23)
    base = nrm(bpf(rng.uniform(-1, 1, n), 90, 1500, circular=True))
    base = base * (0.5 + 0.2 * np.sin(2 * np.pi * (5 / L) * t) + 0.15 * np.sin(2 * np.pi * (11 / L) * t + 1.0))
    buf = np.zeros(n)
    for p in r.uniform(0, L, 40):
        if r.random() < 0.35:
            c = tone('sin', r.uniform(250, 500), r.uniform(100, 200), 0.03, decay=0.008)
        else:
            c = noise(r.uniform(0.01, 0.04), decay=r.uniform(0.004, 0.01), hp=r.uniform(700, 3000), lp=8000)
        place(buf, c, p, r.uniform(0.15, 0.8), wrap=True)
    return base * 0.45 + buf * 0.5


def amb_cave_drone_loop():
    L = 12.0
    n = n_(L)
    t = np.arange(n) / SR
    x = np.zeros(n)
    for f, g, k, ph in [(55, 0.45, 1, 0.0), (82, 0.25, 2, 1.0), (110, 0.18, 3, 2.0), (116, 0.08, 5, 0.5), (165, 0.07, 4, 1.7)]:
        x += g * np.sin(2 * np.pi * f * t + 0.4 * np.sin(2 * np.pi * (k / L) * t + ph)) * \
            (0.7 + 0.3 * np.sin(2 * np.pi * (k / L) * t + ph * 2))
    return x + 0.5 * nrm(lpf(rng.uniform(-1, 1, n), 180, circular=True))


def chain_rattle(seed):
    r = np.random.default_rng(seed)
    buf = np.zeros(n_(1.8))
    t, amp = 0.0, 1.0
    for _ in range(14):
        f = r.uniform(1600, 3400)
        place(buf, mix(tone('tri', f, f * 0.96, 0.07, decay=0.02, vol=0.5), noise(0.04, decay=0.008, hp=2500, vol=0.4)), t, amp)
        t += r.uniform(0.04, 0.13) * (1 + t)
        amp *= 0.88
    return reverb(buf, 1.5, 0.7, 3500)


def rumble(seed, d):
    r = np.random.default_rng(seed)
    x = nrm(lpf(rng.uniform(-1, 1, n_(d)), 170)) * env(d, a=d * 0.35, flat=True, r=d * 0.4)
    clicks = _debris(np.zeros(n_(d)), r, 10, d * 0.8, 400, 1500, d * 0.5)
    return reverb(mix(x, clicks * 0.3), 1.8, 0.5, 1500)


def amb_stone_crumble():
    d = 1.6
    buf = _debris(np.zeros(n_(d)), np.random.default_rng(51), 40, 1.4, 500, 2200, 0.7)
    base = nrm(lpf(rng.uniform(-1, 1, n_(d)), 1200)) * env(d, a=0.1, decay=0.5, r=0.3) * 0.5
    return reverb(mix(buf, base), 1.2, 0.6, 2500)


def amb_creak(seed):
    c = _creak(1.0, 110, 170, seed)
    return reverb(c, 1.8, 0.7, 2500, seed=4)


def amb_distant_thud():
    x = mix(tone('sin', 70, 35, 0.4, decay=0.1), noise(0.3, decay=0.06, lp=700, hp=50, vol=0.7))
    return reverb(lpf(x, 400), 2.5, 1.2, 800)


# =====================================================================  REGISTER
for v in range(1, 5):
    add(PL, f'footstep_stone_{v}', lambda v=v: _step(v), 0.55)
add(PL, 'jump', jump, 0.7)
add(PL, 'double_jump', double_jump, 0.7)
add(PL, 'land_soft', land_soft, 0.6)
add(PL, 'land_hard', land_hard, 0.75)
add(PL, 'land_heavy', land_heavy, 0.85)
add(PL, 'wall_slide_loop', wall_slide_loop, 0.45, True)
add(PL, 'wall_grab', wall_grab, 0.6)
add(PL, 'dash', dash, 0.7)
add(PL, 'dash_ready', dash_ready, 0.5)
add(PL, 'ledge_grab', ledge_grab, 0.6)
add(PL, 'ledge_climb', ledge_climb, 0.65)
add(PL, 'climb_loop', climb_loop, 0.5, True)
add(PL, 'slide', slide, 0.6)
add(PL, 'skid', skid, 0.55)
add(PL, 'hurt', hurt, 0.8)
add(PL, 'death', death, 0.9)
add(PL, 'respawn', respawn, 0.7)
add(PL, 'low_health_heartbeat_loop', low_health_heartbeat_loop, 0.7, True)
add(PL, 'fall_pit', fall_pit, 0.65)

add(HZ, 'spike_extend', spike_extend, 0.75)
add(HZ, 'spike_retract', spike_retract, 0.6)
add(HZ, 'spike_hit', spike_hit, 0.8)
add(HZ, 'saw_loop', saw_loop, 0.5, True)
add(HZ, 'saw_hit', saw_hit, 0.8)
add(HZ, 'pendulum_whoosh', pendulum_whoosh, 0.7)
add(HZ, 'fire_jet', fire_jet, 0.7)
add(HZ, 'arrow_launch', arrow_launch, 0.65)
add(HZ, 'arrow_impact', arrow_impact, 0.7)
add(HZ, 'platform_crack', platform_crack, 0.7)
add(HZ, 'platform_crumble', platform_crumble, 0.75)
add(HZ, 'platform_crash', platform_crash, 0.85)
add(HZ, 'boulder_roll_loop', boulder_roll_loop, 0.6, True)
add(HZ, 'gas_bubble_loop', gas_bubble_loop, 0.45, True)
add(HZ, 'electric_hum_loop', electric_hum_loop, 0.45, True)
add(HZ, 'zap', zap, 0.7)
add(HZ, 'pressure_plate', pressure_plate, 0.65)

add(PZ, 'lever_pull', lever_pull, 0.7)
add(PZ, 'switch_toggle', switch_toggle, 0.6)
add(PZ, 'button_press', button_press, 0.6)
add(PZ, 'door_stone_open', door_stone_open, 0.75)
add(PZ, 'door_stone_close', door_stone_close, 0.8)
add(PZ, 'door_wood_open', door_wood_open, 0.6)
add(PZ, 'door_wood_close', door_wood_close, 0.7)
add(PZ, 'gate_raise', gate_raise, 0.7)
add(PZ, 'gate_lower', gate_lower, 0.75)
add(PZ, 'key_pickup', key_pickup, 0.65)
add(PZ, 'key_use', key_use, 0.6)
add(PZ, 'lock_unlock', lock_unlock, 0.7)
add(PZ, 'block_scrape_loop', block_scrape_loop, 0.55, True)
add(PZ, 'block_thud', block_thud, 0.75)
add(PZ, 'moving_platform_loop', moving_platform_loop, 0.5, True)
add(PZ, 'teleport', teleport, 0.7)
add(PZ, 'puzzle_solved', puzzle_solved, 0.7)
add(PZ, 'puzzle_wrong', puzzle_wrong, 0.6)
add(PZ, 'timer_tick', timer_tick, 0.4)
add(PZ, 'timer_tock', timer_tock, 0.4)
add(PZ, 'timer_expired', timer_expired, 0.7)
add(PZ, 'secret_reveal', secret_reveal, 0.7)

for i, s in enumerate([0, 3, 5, 7, 10], 1):
    add(CO, f'coin_chain_{i}', lambda s=s: coin(s), 0.55)
add(CO, 'gem_pickup', gem_pickup, 0.65)
add(CO, 'powerup_pickup', powerup_pickup, 0.7)
add(CO, 'powerup_activate', powerup_activate, 0.75)
add(CO, 'checkpoint', checkpoint, 0.7)
for i in range(3):
    add(CO, f'star_ding_{i + 1}', lambda i=i: star_ding(i), 0.65)
add(CO, 'achievement', achievement, 0.7)

add(EN, 'enemy_idle_growl', enemy_idle_growl, 0.6)
add(EN, 'enemy_alert', enemy_alert, 0.7)
add(EN, 'enemy_attack', enemy_attack, 0.7)
add(EN, 'enemy_hit', enemy_hit, 0.75)
add(EN, 'enemy_death', enemy_death, 0.8)
add(EN, 'boss_intro', boss_intro, 0.85)
add(EN, 'boss_phase_change', boss_phase_change, 0.85)
add(EN, 'boss_defeat', boss_defeat, 0.9)

add(UI, 'ui_hover', ui_hover, 0.35)
add(UI, 'ui_select', ui_select, 0.45)
add(UI, 'ui_confirm', ui_confirm, 0.5)
add(UI, 'ui_back', ui_back, 0.45)
add(UI, 'ui_pause', ui_pause, 0.5)
add(UI, 'ui_unpause', ui_unpause, 0.5)
add(UI, 'ui_error', ui_error, 0.5)
add(UI, 'ui_tab', ui_tab, 0.4)
add(UI, 'ui_slider_tick', ui_slider_tick, 0.3)

add(STG, 'stinger_game_start', stinger_game_start, 0.85)
add(STG, 'stinger_game_over', stinger_game_over, 0.8)
add(STG, 'stinger_level_complete', stinger_level_complete, 0.8)
add(STG, 'stinger_level_fail', stinger_level_fail, 0.8)

add(AMB, 'amb_room_tone_loop', amb_room_tone_loop, 0.4, True)
add(AMB, 'amb_drips_loop', amb_drips_loop, 0.45, True)
add(AMB, 'amb_wind_loop', amb_wind_loop, 0.4, True)
add(AMB, 'amb_torch_loop', amb_torch_loop, 0.45, True)
add(AMB, 'amb_cave_drone_loop', amb_cave_drone_loop, 0.4, True)
for i in (1, 2):
    add(AMB, f'amb_chain_rattle_{i}', lambda i=i: chain_rattle(60 + i), 0.5)
    add(AMB, f'amb_rumble_{i}', lambda i=i: rumble(70 + i, 2.5 + i), 0.55)
    add(AMB, f'amb_creak_{i}', lambda i=i: amb_creak(80 + i), 0.45)
add(AMB, 'amb_stone_crumble', amb_stone_crumble, 0.5)
add(AMB, 'amb_distant_thud', amb_distant_thud, 0.5)
