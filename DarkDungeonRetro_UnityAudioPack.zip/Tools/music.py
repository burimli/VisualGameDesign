"""Chiptune-meets-dungeon music loops (stereo, seamless: everything wraps round the loop point)."""
from dsp import *
import numpy as np

REG = []


def mf(n):
    return 440.0 * 2 ** ((n - 69) / 12)


# MIDI chord voicings (A minor world, a few borrowed colours)
CH = {'Am': [57, 60, 64], 'F': [53, 57, 60], 'Dm': [50, 53, 57], 'E': [52, 56, 59],
      'C': [48, 52, 55], 'G': [55, 59, 62], 'Bb': [58, 62, 65], 'Gm': [55, 58, 62]}

_C = {}


def make(ins, mid, dur):
    key = (ins, mid, round(dur, 3))
    if key in _C:
        return _C[key]
    f = mf(mid) if mid is not None else None
    if ins == 'lead':
        d = dur + 0.12
        t = tt(d)
        vib = 1 + 0.011 * np.sin(2 * np.pi * 5.5 * t) * np.clip((t - 0.12) / 0.25, 0, 1)
        x = osc('sq', f * vib, 0.25) * env(d, a=0.012, flat=True, r=0.12) * (0.6 + 0.4 * np.exp(-t / 0.3))
    elif ins == 'bass':
        d = dur + 0.04
        fl = np.full(n_(d), f)
        x = (osc('tri', fl) * 0.8 + osc('sq', fl, 0.5) * 0.2) * env(d, a=0.004, decay=max(0.2, dur * 0.9), r=0.04)
    elif ins == 'pad':
        d = dur + 0.6
        fl = np.full(n_(d), f)
        x = (osc('saw', fl * 1.0023) + osc('saw', fl * 0.9977) + osc('tri', fl * 0.5) * 0.8) * \
            env(d, a=0.35, flat=True, r=0.55) * 0.5
    elif ins == 'arp':
        d = min(dur, 0.3) + 0.05
        x = osc('sq', np.full(n_(d), f), 0.125) * env(d, a=0.003, decay=0.08, r=0.03)
    elif ins == 'bell':
        x = bell(f, min(dur, 3.0) + 0.8, 1.0, 0.55)
    elif ins == 'stab':
        d = min(dur, 0.3) + 0.06
        fl = np.full(n_(d), f)
        x = lpf(osc('saw', fl) + osc('sq', fl * 1.005, 0.3), 2400) * env(d, a=0.003, decay=0.1, r=0.04)
    elif ins == 'kick':
        x = mix(tone('sin', 140, 42, 0.3, decay=0.07), noise(0.01, decay=0.003, hp=1500, vol=0.3))
    elif ins == 'snare':
        x = crush(mix(noise(0.2, decay=0.05, hp=1200, vol=0.8), tone('tri', 200, 150, 0.12, decay=0.03, vol=0.5)), 7)
    elif ins == 'hat':
        x = crush(noise(0.06, decay=0.012, hp=6500, vol=0.5), 7)
    elif ins == 'ohat':
        x = crush(noise(0.25, decay=0.07, hp=6000, vol=0.4), 7)
    elif ins == 'tom':
        x = mix(tone('sin', 120, 60, 0.6, decay=0.16, vol=0.9), noise(0.05, decay=0.01, lp=1500, hp=100, vol=0.3))
    else:
        raise ValueError(ins)
    _C[key] = x
    return x


def render(bpm, bars, ev, mixdef, rv=(2.0, 3000, 0.7), peak=0.85):
    spb = 60.0 / bpm
    L = int(round(bars * 4 * spb * SR))
    bufs = {}
    for ins, mid, beat, beats, vel in ev:
        b = bufs.setdefault(ins, np.zeros(L))
        place(b, make(ins, mid, beats * spb) * vel, beat * spb, wrap=True)
    dl, dr, send = np.zeros(L), np.zeros(L), np.zeros(L)
    for ins, b in bufs.items():
        c = mixdef[ins]
        x = b
        if c.get('lp'):
            x = lpf(x, c['lp'], circular=True)
        if c.get('hp'):
            x = hpf(x, c['hp'], circular=True)
        x = x * c['gain']
        ang = (c.get('pan', 0) + 1) * np.pi / 4
        dl += x * np.cos(ang)
        dr += x * np.sin(ang)
        send += x * c.get('send', 0)
    t, dark, w = rv
    wl = reverb(send, t, 1.0, dark, seed=7, circular=True, wet_only=True)
    wr = reverb(send, t, 1.0, dark, seed=8, circular=True, wet_only=True)
    return norm(np.stack([dl + w * wl, dr + w * wr], axis=1), peak)


def arp_tones(c):
    return [t + 12 for t in CH[c]] + [t + 24 for t in CH[c]]


# ------------------------------------------------------------------ MENU THEME
def menu_theme():
    bpm, bars = 70, 16
    prog = ['Am', 'F', 'Dm', 'E'] * 2
    mel = {'Am': [(0, 76, 2), (2, 72, 1), (3, 71, 1), (4, 69, 3)],
           'F': [(0, 77, 2), (2, 76, 1), (3, 72, 1), (4, 69, 2), (6, 72, 1.5)],
           'Dm': [(0, 74, 2), (2, 77, 1), (3, 76, 1), (4, 74, 2), (6, 69, 2)],
           'E': [(0, 76, 1.5), (1.5, 71, 0.5), (2, 68, 2), (4, 71, 1), (5, 76, 1), (6, 80, 2)]}
    ev = []
    for i, c in enumerate(prog):
        b0 = i * 8
        for t_ in CH[c]:
            ev.append(('pad', t_, b0, 8, 0.5))
        ev.append(('bass', CH[c][0] - 12, b0, 8, 0.9))
        ev.append(('tom', None, b0, 1, 0.6))
        if i >= 4:
            ev.append(('tom', None, b0 + 4, 1, 0.35))
        for o, mn, bt in mel[c]:
            ev.append(('bell' if i < 4 else 'lead', mn, b0 + o, bt, 0.6 if i < 4 else 0.35))
        if i >= 4:
            tones = [t + 12 for t in CH[c]]
            for k in range(16):
                ev.append(('arp', tones[[0, 1, 2, 1][k % 4]], b0 + k * 0.5, 0.5, 0.18))
    mixdef = {'pad': dict(gain=0.7, pan=0, lp=1600, send=0.6), 'bass': dict(gain=0.9, pan=0, lp=500, send=0.1),
              'bell': dict(gain=0.55, pan=-0.25, send=1.0), 'lead': dict(gain=0.4, pan=0.25, send=0.6),
              'arp': dict(gain=0.45, pan=0.5, send=0.5), 'tom': dict(gain=0.7, pan=0, send=0.8)}
    return render(bpm, bars, ev, mixdef, rv=(2.8, 2800, 1.2))


# ------------------------------------------------------------------ EXPLORE / CALM PUZZLE
def explore_calm():
    bpm, bars = 84, 16
    prog = ['Am', 'Am', 'F', 'G'] * 4
    phrA = [(0, 76, 1.5), (1.5, 74, 0.5), (2, 72, 1), (3, 69, 1), (4, 71, 1.5), (5.5, 72, 0.5), (6, 74, 2)]
    phrB = [(0, 77, 1.5), (1.5, 76, 0.5), (2, 72, 1), (3, 69, 1), (4, 74, 1.5), (5.5, 71, 0.5), (6, 67, 2)]
    pat = [0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 0, 1, 2, 3, 2, 1]
    ev = []
    for b, c in enumerate(prog):
        b0 = b * 4
        r = CH[c][0]
        for t_ in CH[c]:
            ev.append(('pad', t_, b0, 4, 0.3))
        for o, mid, bt in [(0, r - 12, 1), (1.5, r - 12, 0.5), (2, r - 5, 1), (3, r, 0.75)]:
            ev.append(('bass', mid, b0 + o, bt, 0.8))
        tones = arp_tones(c)
        for k in range(16):
            ev.append(('arp', tones[pat[k]], b0 + k * 0.25, 0.25, 0.2 if k % 4 == 0 else 0.13))
        if b >= 2:
            ev.append(('kick', None, b0, 1, 0.5))
            ev.append(('kick', None, b0 + 2, 1, 0.4))
        for k in range(8):
            ev.append(('hat', None, b0 + k * 0.5, 0.25, 0.1 if k % 2 == 0 else 0.16))
        if b >= 4 and b % 4 in (0, 2):
            for o, mid, bt in (phrA if b % 4 == 0 else phrB):
                ev.append(('lead', mid, b0 + o, bt, 0.4))
    mixdef = {'pad': dict(gain=0.6, pan=0, lp=1500, send=0.5), 'bass': dict(gain=0.9, pan=0, lp=600, send=0.05),
              'arp': dict(gain=0.5, pan=0.4, send=0.4), 'kick': dict(gain=0.8, pan=0, lp=300),
              'hat': dict(gain=0.5, pan=-0.3, hp=5000), 'lead': dict(gain=0.5, pan=-0.2, send=0.5)}
    return render(bpm, bars, ev, mixdef, rv=(2.0, 3000, 0.9))


# ------------------------------------------------------------------ TENSE / TIMED
def tense():
    bpm, bars = 126, 16
    prog = ['Am', 'Am', 'Bb', 'Am', 'Am', 'Bb', 'Gm', 'E'] * 2
    riff = [76, None, 75, 76, None, 72, None, 71]
    ev = []
    for b, c in enumerate(prog):
        b0 = b * 4
        r = CH[c][0]
        off = r - 57
        for i in range(8):
            ev.append(('bass', r - 12, b0 + i * 0.5, 0.5, 0.9 * (1.0 if i in (0, 3, 6) else 0.7)))
        tones = arp_tones(c)
        for k in range(16):
            ev.append(('arp', tones[[0, 3, 1, 4, 2, 5, 3, 1][k % 8]], b0 + k * 0.25, 0.25, 0.17))
        for beat in range(4):
            ev.append(('kick', None, b0 + beat, 1, 0.9))
        if b >= 2:
            for beat in (1, 3):
                ev.append(('snare', None, b0 + beat, 1, 0.7))
        for k in range(8):
            ev.append(('hat' if k % 2 == 0 else 'ohat', None, b0 + k * 0.5, 0.5, 0.25 if k % 2 == 0 else 0.18))
        if b % 2 == 0:
            for o in (0, 1.5, 3):
                for t_ in CH[c]:
                    ev.append(('stab', t_ + 12, b0 + o, 0.5, 0.25))
        if b >= 8:
            for i, mid in enumerate(riff):
                if mid:
                    ev.append(('lead', mid + off, b0 + i * 0.5, 0.5, 0.35))
    mixdef = {'bass': dict(gain=0.9, pan=0, lp=700, send=0.05), 'arp': dict(gain=0.5, pan=0.45, send=0.3),
              'kick': dict(gain=1.0, pan=0, lp=400), 'snare': dict(gain=0.7, pan=0.05, send=0.3),
              'hat': dict(gain=0.5, pan=-0.35, hp=5000), 'ohat': dict(gain=0.5, pan=0.35, hp=5000),
              'stab': dict(gain=0.6, pan=-0.3, send=0.4), 'lead': dict(gain=0.5, pan=0.15, send=0.35)}
    return render(bpm, bars, ev, mixdef, rv=(1.4, 3000, 0.7))


# ------------------------------------------------------------------ BOSS
def boss():
    bpm, bars = 150, 16
    prog = ['Am', 'Am', 'Bb', 'Am', 'Am', 'Am', 'Gm', 'E'] * 2
    accent = [1, .6, .6, 1, .6, .6, 1, .6, 1, .6, .6, 1, .6, 1, .6, .6]
    kicks = {0, 2, 3, 6, 8, 10, 11, 14}
    riff = [(0, 76, 1), (1, 75, 0.5), (1.5, 72, 0.5), (2, 76, 1), (3, 77, 0.5), (3.5, 76, 0.5)]
    ev = []
    for b, c in enumerate(prog):
        b0 = b * 4
        r = CH[c][0]
        off = r - 57
        for k in range(16):
            ev.append(('bass', (r - 12) + (6 if k == 11 else 0), b0 + k * 0.25, 0.25, 0.9 * accent[k]))
            if k in kicks:
                ev.append(('kick', None, b0 + k * 0.25, 0.25, 0.95))
            if k in (4, 12):
                ev.append(('snare', None, b0 + k * 0.25, 0.25, 0.85))
            if k % 2 == 0:
                ev.append(('hat', None, b0 + k * 0.25, 0.25, 0.22))
        if b % 2 == 0:
            ev.append(('ohat', None, b0 + 3.5, 0.5, 0.3))
        for t_ in CH[c]:
            ev.append(('pad', t_, b0, 4, 0.3))
        if b >= 2:
            tones = arp_tones(c)
            for k in range(16):
                ev.append(('arp', tones[[0, 2, 1, 3, 2, 4, 3, 5][k % 8]], b0 + k * 0.25, 0.25, 0.13))
        if b >= 4:
            for o, mid, bt in riff:
                ev.append(('lead', mid + off, b0 + o, bt, 0.45))
    mixdef = {'bass': dict(gain=0.95, pan=0, lp=800, send=0.03), 'kick': dict(gain=1.0, pan=0, lp=450),
              'snare': dict(gain=0.8, pan=0.05, send=0.35), 'hat': dict(gain=0.5, pan=-0.35, hp=5000),
              'ohat': dict(gain=0.5, pan=0.35, hp=5000), 'pad': dict(gain=0.5, pan=0, lp=1800, send=0.3),
              'arp': dict(gain=0.5, pan=0.5, send=0.3), 'lead': dict(gain=0.55, pan=-0.15, send=0.35)}
    return render(bpm, bars, ev, mixdef, rv=(1.2, 2800, 0.7))


# ------------------------------------------------------------------ CREDITS
def credits():
    bpm, bars = 76, 16
    prog = ['Am', 'F', 'C', 'G'] * 2
    pat = [0, 1, 2, 3, 2, 1, 0, 1, 2, 3, 2, 1, 0, 1, 2, 1]
    ev = []
    for i, c in enumerate(prog):
        b0 = i * 8
        for t_ in CH[c]:
            ev.append(('pad', t_, b0, 8, 0.45))
        ev.append(('bass', CH[c][0] - 12, b0, 4, 0.8))
        ev.append(('bass', CH[c][0] - 12, b0 + 4, 4, 0.7))
        tones = [t + 12 for t in CH[c]] + [CH[c][0] + 24]
        for k in range(16):
            ev.append(('bell', tones[pat[k]], b0 + k * 0.5, 1.0, 0.3))
        if i >= 4:
            top, mid, low = CH[c][2] + 12, CH[c][1] + 12, CH[c][0] + 12
            for o, mn, bt in [(0, top, 2), (2, mid, 1), (3, top, 1), (4, mid, 2), (6, low, 2)]:
                ev.append(('lead', mn, b0 + o, bt, 0.3))
    mixdef = {'pad': dict(gain=0.7, pan=0, lp=1500, send=0.6), 'bass': dict(gain=0.85, pan=0, lp=500, send=0.1),
              'bell': dict(gain=0.5, pan=0.3, send=0.9), 'lead': dict(gain=0.5, pan=-0.25, send=0.6)}
    return render(bpm, bars, ev, mixdef, rv=(2.6, 2800, 1.0))


for name, fn in [('music_menu_theme', menu_theme), ('music_explore_calm', explore_calm),
                 ('music_tense_timed', tense), ('music_boss', boss), ('music_credits', credits)]:
    REG.append(('Music', name, fn, 0.85, True))
