# Dark Dungeon Retro Audio Pack (Unity)

114 sounds for a 2D dungeon parkour puzzler, synthesized from scratch in code (no samples, no third-party audio),
so you can use them in your game freely, including commercially.

Style: 8-bit pulse/triangle voices, bitcrushed hits, low drones and stone-y reverb. Everything is in A minor.

## Install
Copy the `Assets` folder into your Unity project's `Assets` folder (merge when asked).

## What's inside
| Folder | Contents |
|---|---|
| `Audio/SFX/Player` | footsteps x4, jump, double jump, 3 landings, wall slide/grab, dash, ledge grab/climb, rope climb, slide, skid, hurt, death, respawn, low-health heartbeat, pit fall |
| `Audio/SFX/Hazards` | spikes, saw blade, pendulum, fire jet, arrows, crumbling platform (crack/crumble/crash), boulder, gas, electric hum, zap, pressure plate |
| `Audio/SFX/Puzzle` | lever, switch, button, stone and wood doors, gate, key/lock, pushable block, moving platform, teleport, solved/wrong, timer tick/tock/expired, secret reveal |
| `Audio/SFX/Collectibles` | coin chain x5 (rising pitch), gem, power-ups, checkpoint, star dings x3, achievement |
| `Audio/SFX/Enemies` | growl, alert, attack, hit, death, boss intro / phase change / defeat |
| `Audio/SFX/UI` | hover, select, confirm, back, pause, unpause, error, tab, slider tick |
| `Audio/Ambience` | 5 seamless loops (room tone, drips, wind, torch, cave drone) + one-shots (chains, rumbles, creaks, crumble, distant thud) |
| `Audio/Music` | menu theme, calm puzzle, tense/timed, boss, credits (stereo loops, .ogg) + `Stingers` (game start, game over, level complete, level fail) |

Anything with `_loop` in the name (and all music and ambience loops) loops seamlessly.
`AUDIO_LIST.csv` has every file with its length and loudness.

## Recommended Unity import settings
| Type | Load Type | Compression | Notes |
|---|---|---|---|
| Short SFX | Decompress On Load | PCM or ADPCM | Force To Mono is fine |
| Loops (`_loop`) | Decompress On Load | ADPCM | Tick the loop box on your AudioSource |
| Ambience | Compressed In Memory | Vorbis | |
| Music | Streaming | Vorbis | Set `AudioSource.loop = true`; the loops are sample-exact |

## Using it
- **Variants:** put `footstep_stone_1..4` (or `coin_chain_1..5`, `land_*`) into `SfxPlayer` (in `Scripts/Audio`) and call `Play()`.
  It picks a random clip with a small pitch and volume change.
- **Separate volume sliders:** make three Audio Mixer groups (Music, SFX, Ambience) and route your AudioSources to them.
- **Coin chains:** play `coin_chain_1` through `_5` in order as the player grabs coins in quick succession; reset after ~1 second.
- **Timers:** alternate `timer_tick` and `timer_tock` once per second.
- **Adaptive feel:** crossfade `music_explore_calm` into `music_tense_timed` (same key) when a timed room starts.

## Regenerating or tweaking
`Tools/` has the Python generator (needs `numpy`, and `ffmpeg` for the .ogg music):

    python3 Tools/build.py OutputFolder
    MUSIC_FORMAT=wav python3 Tools/build.py OutputFolder     # lossless music

Each sound is a short function in `sfx.py` / `music.py`; change a frequency, decay or filter and re-run.
